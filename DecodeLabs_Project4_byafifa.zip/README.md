# DecodeLabs – Project 4: Data Visualization

## Project overview
This project turns the cleaned e-commerce orders dataset into visual summaries and business observations. It was prepared as part of the DecodeLabs Data Analytics Internship.

## Dataset
- 1,200 order records
- 11 analysis fields
- Date coverage: 1 January 2023 to 30 June 2025

## Tools
- Python
- pandas
- Matplotlib

## Visualizations
- Orders by product
- Orders by order status
- Monthly order trend
- Orders by referral source
- Orders by payment method

## Key findings
- Printer has the highest order count (181), while Phone has the lowest (156).
- Cancelled and Returned orders total 497 records, approximately 41.4% of all orders.
- June 2024 has the highest monthly order count (53); January 2025 has the lowest (27).
- Instagram is the largest recorded referral source (259 orders).
- Order counts are relatively evenly distributed across payment methods.

## Important interpretation note
The sum of `total_price` includes every order status: Cancelled, Returned, Pending, Shipped and Delivered. It is therefore described as **recorded order value**, not recognized revenue or completed sales. The dataset does not explain why orders were cancelled or returned, nor does it include marketing spend or profit margins.

## Repository contents
- `orders_cleaned_for_visualization.csv` – cleaned dataset used for the visuals
- `DecodeLabs_Project4_Report.pdf` – project report with findings and recommendations
- `visuals/` – chart images used to communicate the main patterns

## Suggested GitHub topics
`data-visualization`, `data-analytics`, `python`, `pandas`, `matplotlib`, `decodelabs`

---
**Project:** DecodeLabs Data Analytics Internship  
**Focus:** Data Visualization and Data Storytelling
