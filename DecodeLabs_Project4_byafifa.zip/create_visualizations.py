import pandas as pd
import matplotlib.pyplot as plt

df = pd.read_csv("orders_cleaned_for_visualization.csv")
df["order_date"] = pd.to_datetime(df["order_date"])

def bar_chart(series, title, xlabel, ylabel, filename):
    plt.figure(figsize=(9, 5))
    ax = series.sort_values().plot(kind="barh")
    ax.set_title(title)
    ax.set_xlabel(xlabel)
    ax.set_ylabel(ylabel)
    ax.grid(axis="x", alpha=0.25)
    plt.tight_layout()
    plt.savefig(filename, dpi=180)
    plt.close()

bar_chart(df.groupby("product").size(), "Orders by product", "Orders", "Product", "orders_by_product.png")
bar_chart(df["order_status"].value_counts(), "Orders by status", "Orders", "Status", "orders_by_status.png")
bar_chart(df["referral_source"].value_counts(), "Orders by referral source", "Orders", "Referral source", "orders_by_referral_source.png")
bar_chart(df["payment_method"].value_counts(), "Orders by payment method", "Orders", "Payment method", "orders_by_payment_method.png")

monthly = df.set_index("order_date").resample("MS").size()
plt.figure(figsize=(10, 5))
ax = monthly.plot(marker="o")
ax.set_title("Monthly order trend")
ax.set_xlabel("Month")
ax.set_ylabel("Orders")
ax.grid(alpha=0.25)
plt.tight_layout()
plt.savefig("monthly_order_trend.png", dpi=180)
